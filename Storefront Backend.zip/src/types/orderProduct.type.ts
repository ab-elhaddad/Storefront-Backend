export type OrderProduct = {
  id?: number;
  quantity: number;
  order_id: number;
  product_id: number;
};
